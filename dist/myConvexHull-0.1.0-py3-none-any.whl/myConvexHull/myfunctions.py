class myConvexHull:
    """
    Instantiate a convex hull from ndarray
    """

    EPSILON = 1e-10

    def __init__(self, ndarray):
        self.simplices = [] # himpunan solusi berisi garis dari dua titik pembentuk convex hull
        self.array = ndarray.tolist()
        self.array.sort() # convert array to sorted list
        self.convex_hull()

    def convex_hull(self):
        """
        
        """
        # dua titik ekstrem
        left_point = self.array[0]
        right_point = self.array[len(self.array) - 1]
        self.simplices.append([left_point, right_point])
        self.simplices.append([right_point, left_point])

        left_partition = self.partisi(left_point, right_point, self.array)
        right_partition = self.partisi(right_point, left_point, self.array)
       
        self.find_hull(left_partition, left_point, right_point)
        self.find_hull(right_partition, right_point, left_point)

    def find_hull(self, array, pangkal, ujung):
        """
        recursive to find point to form convex hull
        """
        if(len(array) == 0):
            return
        else:
            farrest_point = self.get_farrest_point(array, pangkal, ujung)
            self.simplices = [x for x in self.simplices if x != [pangkal, ujung]]
            self.simplices.append([pangkal, farrest_point])
            self.simplices.append([farrest_point, ujung])

            array = [x for x in array if x != farrest_point]

            left_partition = self.partisi(pangkal, farrest_point, array)
            right_partition = self.partisi(farrest_point, ujung, array)

            self.find_hull(left_partition, pangkal, farrest_point)
            self.find_hull(right_partition, farrest_point, ujung)

    def get_farrest_point(self, array, p1, p2):
        """
        :param array: array 2 dimensi
        :return: array 2 dimensi
        """
        max_distance = 0
        farrest_point = None
        for p in array:
            d = self.distance(p, p1, p2)
            if(d > max_distance):
                max_distance = d
                farrest_point = p
        return farrest_point

    def partisi(self, pangkal, ujung, array):
        """
        determinan positif = ada di kiri / atas garis relatif terhadap pangkal dan ujungnya
        """
        partition_array = []
        for i in range(len(array)):
            det = self.determinant(pangkal, ujung, array[i])
            if(det > 0 and abs(det) > self.EPSILON):
                partition_array.append(array[i])
        return partition_array

    def distance(self, p0, p1, p2):
        """
        return distance from p0 to line formed by p1 and p2
        """
        X = 0
        Y = 1  
        return abs((p2[X] - p1[X]) * (p1[Y] - p0[Y]) - (p1[X] - p0[X]) * (p2[Y] - p1[Y])) / (((p2[X] - p1[X]) ** 2 + (p2[Y] - p1[Y]) ** 2) ** 0.5)

    def determinant(self, p1, p2, p3):
        """
        :param p1: array 2 dimensi
        :param p2: array 2 dimensi
        :param p3: array 2 dimensi
        :return: determinant
        """
        X = 0
        Y = 1
        return (p1[X] * p2[Y] + p2[X] * p3[Y] + p3[X] * p1[Y]) - (p1[Y] * p2[X] + p2[Y] * p3[X] + p3[Y] * p1[X])